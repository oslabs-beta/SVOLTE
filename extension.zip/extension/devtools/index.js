/**
This script is run whenever the devtools are open.
In here, we can create our panel.
*/

chrome.devtools.panels.create('SVOLTE', '/icons/128.png', './devtools/panel/panel.html');


